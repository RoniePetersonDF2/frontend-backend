import './App.css'
import Button from './components/Button'

function App() {

  return (
    <>
      <Button  />
    </>
  )
}

export default App
