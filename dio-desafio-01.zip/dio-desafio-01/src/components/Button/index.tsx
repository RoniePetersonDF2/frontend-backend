import { Botao } from './style'
function Button () {
    return (
        <Botao $primary>Meu styled component</Botao>
    )
}

export default Button