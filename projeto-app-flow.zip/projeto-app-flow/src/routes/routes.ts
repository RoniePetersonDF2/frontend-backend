
export enum Routes {
    LIST = "/api/list",
    EPISODE = "/api/episode"
}