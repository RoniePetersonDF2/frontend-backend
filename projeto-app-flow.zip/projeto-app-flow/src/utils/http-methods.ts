export enum HttpMethod {
    GET = "GET",
    POST = "POST",
    PUT = "PUT",
    PATH = "PATH",
    DELETE = "DELETE"
}