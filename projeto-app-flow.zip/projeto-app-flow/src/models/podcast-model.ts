export interface PodcastModel{
    podcastName: string, 
    episode: string,
    videoID:string,
    categories:string[]
}