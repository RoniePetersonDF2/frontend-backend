export {};

//# sourceMappingURL=QueryResultCacheOptions.js.map
