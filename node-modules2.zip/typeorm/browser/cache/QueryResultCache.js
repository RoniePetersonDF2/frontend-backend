export {};

//# sourceMappingURL=QueryResultCache.js.map
