export {};

//# sourceMappingURL=CockroachConnectionOptions.js.map
