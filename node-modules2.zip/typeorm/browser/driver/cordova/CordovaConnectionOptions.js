export {};

//# sourceMappingURL=CordovaConnectionOptions.js.map
