export {};

//# sourceMappingURL=AuroraPostgresConnectionOptions.js.map
