export {};

//# sourceMappingURL=MongoConnectionOptions.js.map
