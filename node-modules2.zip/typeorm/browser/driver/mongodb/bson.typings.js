export { BSON };

//# sourceMappingURL=bson.typings.js.map
