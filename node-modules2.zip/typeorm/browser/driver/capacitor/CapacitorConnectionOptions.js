export {};

//# sourceMappingURL=CapacitorConnectionOptions.js.map
