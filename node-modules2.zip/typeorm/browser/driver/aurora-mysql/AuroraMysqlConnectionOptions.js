export {};

//# sourceMappingURL=AuroraMysqlConnectionOptions.js.map
