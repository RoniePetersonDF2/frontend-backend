export {};

//# sourceMappingURL=AuroraMysqlConnectionCredentialsOptions.js.map
