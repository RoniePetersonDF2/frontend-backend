/**
 * Creates a "level"/"length" column to the table that holds a closure table.
 */
export declare function TreeLevelColumn(): PropertyDecorator;
