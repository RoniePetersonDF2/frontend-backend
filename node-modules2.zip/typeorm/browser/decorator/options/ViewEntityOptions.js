export {};

//# sourceMappingURL=ViewEntityOptions.js.map
