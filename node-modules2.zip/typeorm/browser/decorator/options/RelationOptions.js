export {};

//# sourceMappingURL=RelationOptions.js.map
