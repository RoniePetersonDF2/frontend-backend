export {};

//# sourceMappingURL=SpatialColumnOptions.js.map
