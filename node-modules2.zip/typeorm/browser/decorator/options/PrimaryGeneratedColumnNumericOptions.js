export {};

//# sourceMappingURL=PrimaryGeneratedColumnNumericOptions.js.map
