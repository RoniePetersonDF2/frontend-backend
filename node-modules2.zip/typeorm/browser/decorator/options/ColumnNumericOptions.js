export {};

//# sourceMappingURL=ColumnNumericOptions.js.map
