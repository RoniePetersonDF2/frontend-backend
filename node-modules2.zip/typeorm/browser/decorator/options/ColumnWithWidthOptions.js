export {};

//# sourceMappingURL=ColumnWithWidthOptions.js.map
