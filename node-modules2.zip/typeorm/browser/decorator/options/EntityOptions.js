export {};

//# sourceMappingURL=EntityOptions.js.map
