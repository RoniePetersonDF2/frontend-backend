export {};

//# sourceMappingURL=VirtualColumnOptions.js.map
