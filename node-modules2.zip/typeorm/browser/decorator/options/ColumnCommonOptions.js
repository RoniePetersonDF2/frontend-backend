export {};

//# sourceMappingURL=ColumnCommonOptions.js.map
