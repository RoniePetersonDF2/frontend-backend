export {};

//# sourceMappingURL=ColumnHstoreOptions.js.map
