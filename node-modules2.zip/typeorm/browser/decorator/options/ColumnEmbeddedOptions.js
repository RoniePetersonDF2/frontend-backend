export {};

//# sourceMappingURL=ColumnEmbeddedOptions.js.map
