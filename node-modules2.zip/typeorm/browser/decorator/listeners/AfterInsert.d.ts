/**
 * Calls a method on which this decorator is applied after this entity insertion.
 */
export declare function AfterInsert(): PropertyDecorator;
