/**
 * Calls a method on which this decorator is applied after this entity removal.
 */
export declare function AfterRemove(): PropertyDecorator;
