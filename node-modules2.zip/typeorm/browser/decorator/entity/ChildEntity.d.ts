/**
 * Special type of the table used in the single-table inherited tables.
 */
export declare function ChildEntity(discriminatorValue?: any): ClassDecorator;
