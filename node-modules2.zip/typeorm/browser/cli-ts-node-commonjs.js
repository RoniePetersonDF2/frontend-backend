#!/usr/bin/env node
require("ts-node").register();
import "./cli";

//# sourceMappingURL=cli-ts-node-commonjs.js.map
