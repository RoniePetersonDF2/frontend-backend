export {};

//# sourceMappingURL=RelationType.js.map
