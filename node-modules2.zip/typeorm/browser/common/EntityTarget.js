export {};

//# sourceMappingURL=EntityTarget.js.map
