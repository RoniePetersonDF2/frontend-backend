export {};

//# sourceMappingURL=ObjectType.js.map
