export {};

//# sourceMappingURL=ObjectLiteral.js.map
