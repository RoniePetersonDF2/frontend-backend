export {};

//# sourceMappingURL=BaseConnectionOptions.js.map
