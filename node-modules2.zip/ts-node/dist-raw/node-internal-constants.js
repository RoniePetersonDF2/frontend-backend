// Copied from https://github.com/nodejs/node/blob/master/lib/internal/constants.js
module.exports = {
  CHAR_FORWARD_SLASH: 47, /* / */
};
