require('./').install({
    hookRequire: true
});
