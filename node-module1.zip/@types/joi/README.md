This is a stub types definition for @types/joi (https://github.com/sideway/joi#readme).

joi provides its own type definitions, so you don't need @types/joi installed!