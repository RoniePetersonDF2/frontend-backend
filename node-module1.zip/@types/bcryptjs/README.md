# Installation
> `npm install --save @types/bcryptjs`

# Summary
This package contains type definitions for bcryptjs (https://github.com/dcodeIO/bcrypt.js).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/bcryptjs.

### Additional Details
 * Last updated: Mon, 06 Nov 2023 22:41:04 GMT
 * Dependencies: none

# Credits
These definitions were written by [Joshua Filby](https://github.com/Joshua-F), [Rafael Kraut](https://github.com/RafaelKr), and [Branislav Holý](https://github.com/branoholy).
