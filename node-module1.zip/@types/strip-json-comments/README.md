# Installation
> `npm install --save @types/strip-json-comments`

# Summary
This package contains type definitions for strip-json-comments (https://github.com/sindresorhus/strip-json-comments).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/strip-json-comments

Additional Details
 * Last updated: Mon, 21 Aug 2017 22:03:22 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Dylan R. E. Moonfire <https://github.com/dmoonfire>.
