# Installation
> `npm install --save @types/swagger-ui-express`

# Summary
This package contains type definitions for swagger-ui-express (https://github.com/scottie1984/swagger-ui-express).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/swagger-ui-express.

### Additional Details
 * Last updated: Tue, 29 Oct 2024 17:34:47 GMT
 * Dependencies: [@types/express](https://npmjs.com/package/@types/express), [@types/serve-static](https://npmjs.com/package/@types/serve-static)

# Credits
These definitions were written by [Dmitry Rogozhny](https://github.com/dmitryrogozhny), and [Florian Imdahl](https://github.com/ffflorian).
